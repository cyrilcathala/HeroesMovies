﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Microsoft.Extensions.DependencyInjection;

namespace Sample.Views
{
	public class ContentPageBase<TViewModel> : ContentPage
	{
		public TViewModel ViewModel => (TViewModel)BindingContext;

		public ContentPageBase()
		{
			On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);

			SetViewModel();

			ControlTemplate = (ControlTemplate)Xamarin.Forms.Application.Current.Resources["DefaultPageTemplate"];
		}

		private void SetViewModel()
		{
			BindingContext = App.Services.GetRequiredService<TViewModel>();
		}
	}
}

