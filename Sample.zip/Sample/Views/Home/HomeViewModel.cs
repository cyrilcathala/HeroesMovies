﻿using System;

namespace Sample.Views
{
    public class HomeViewModel
    {
        
    }
}
