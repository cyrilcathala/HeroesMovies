﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Sample.Views
{
	public partial class HomePage
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
